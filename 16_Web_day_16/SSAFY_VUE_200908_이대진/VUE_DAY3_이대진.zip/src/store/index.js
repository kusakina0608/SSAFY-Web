import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    salt: 30,
    message: "치킨은 맛있다"
  },
  mutations: {
    SET_SALT(state, value){
      state.salt = value;
    },
    SET_MSG(state, value){
      state.message = value;
    }
  },
  actions: {
  },
  modules: {
  }
})
