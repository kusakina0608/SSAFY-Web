<template>
  <div>
    후라이드
  </div>
</template>

<script>
export default {
    props:['']
}
</script>

<style>

</style>